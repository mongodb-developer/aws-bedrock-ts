"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const axios_1 = __importDefault(require("axios"));
const handler = async (event, context) => {
    var _a, _b;
    const { agent, actionGroup, function: functionName, parameters } = event;
    // Extract query and maxResults from parameters
    const query = ((_a = parameters.find(param => param.name === 'query')) === null || _a === void 0 ? void 0 : _a.value) || 'AWS services';
    const maxResults = parseInt(((_b = parameters.find(param => param.name === 'maxResults')) === null || _b === void 0 ? void 0 : _b.value) || '5', 10);
    // YouTube Data API v3 search endpoint
    const apiKey = process.env.YOUTUBE_API_KEY;
    const baseUrl = 'https://www.googleapis.com/youtube/v3/search';
    // Construct the URL with query parameters
    const params = new URLSearchParams({
        part: 'snippet',
        q: query,
        type: 'video',
        maxResults: maxResults.toString(),
        key: apiKey
    });
    try {
        // Make the API request
        const response = await axios_1.default.get(`${baseUrl}?${params}`);
        const searchResults = response.data;
        // Process the search results
        const videos = searchResults.items.map(item => ({
            title: item.snippet.title,
            description: item.snippet.description,
            thumbnail: item.snippet.thumbnails.default.url,
            video_id: item.id.videoId,
            url: `https://www.youtube.com/watch?v=${item.id.videoId}`
        }));
        // Prepare the response
        let responseText = `Here are ${videos.length} YouTube videos related to '${query}':\n\n`;
        videos.forEach((video, index) => {
            responseText += `${index + 1}. ${video.title}\n   ${video.url}\n\n`;
        });
        const actionResponse = {
            actionGroup,
            function: functionName,
            functionResponse: {
                responseBody: {
                    TEXT: {
                        body: responseText
                    }
                }
            }
        };
        const functionResponse = { response: actionResponse, messageVersion: event.messageVersion };
        console.log(`Response: ${JSON.stringify(functionResponse)}`);
        return functionResponse;
    }
    catch (error) {
        console.error('Error:', error);
        throw error;
    }
};
exports.handler = handler;
